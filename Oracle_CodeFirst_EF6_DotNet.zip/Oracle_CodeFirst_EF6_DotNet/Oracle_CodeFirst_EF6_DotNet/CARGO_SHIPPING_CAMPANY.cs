﻿namespace Oracle_CodeFirst_EF6_DotNet
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("SHIPPING_COMPANY.CARGO_SHIPPING_CAMPANY")]
    public partial class CARGO_SHIPPING_CAMPANY
    {
        [Key]
        public decimal COMPANY_NUMBER { get; set; }

        [StringLength(100)]
        public string COMPANY_NAME { get; set; }

        [StringLength(100)]
        public string HEADQUARTERS { get; set; }
    }
}

