﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Oracle_CodeFirst_EF6_DotNet
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            var CompanyInfo = new CARGO_SHIPPING_CAMPANY
            {
                COMPANY_NUMBER = 1201,
                COMPANY_NAME = "CMA CGM",
                HEADQUARTERS = "FRANCE"
            };
            using (var Context = new Shipping())
            {
                Context.CARGO_SHIPPING_CAMPANY.Add(CompanyInfo);
                Context.SaveChanges();
            }
        }
    }
}
