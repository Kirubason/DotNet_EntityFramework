namespace Oracle_CodeFirst_EF6_DotNet.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class createCargoTable : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "SHIPPING_COMPANY.CARGO_SHIPPING_CAMPANY",
                c => new
                    {
                        COMPANY_NUMBER = c.Decimal(nullable: false, precision: 18, scale: 2),
                        COMPANY_NAME = c.String(maxLength: 100),
                        HEADQUARTERS = c.String(maxLength: 100),
                    })
                .PrimaryKey(t => t.COMPANY_NUMBER);
            
        }
        
        public override void Down()
        {
            DropTable("SHIPPING_COMPANY.SHIPPING_COMPANY");
            DropTable("SHIPPING_COMPANY.CARGO_SHIPPING_CAMPANY");
        }
    }
}
