﻿Visual Studio 2019
Oracle Database + SQL Developer

ODTforVS2019 - Oracle Developer Tools for Visual Studio



Link : https://www.oracle.com/database/technologies/dotnet-odtvsix-vs2019-downloads.html#


Below comments will be used for the Entity Framework code first migration

enable-migrations
add-migration createCargoTable
update-database
