namespace Oracle_CodeFirst_EF6_DotNet
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("SHIPPING_COMPANY.SHIPPING_COMPANY")]
    public partial class SHIPPING_COMPANY
    {
        [Key]
        public decimal COMPANY_NUMBER { get; set; }

        [StringLength(100)]
        public string COMPANY_NAME { get; set; }

        [StringLength(100)]
        public string HEADQUARTERS { get; set; }
    }
}
