using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;

namespace Oracle_CodeFirst_EF6_DotNet
{
    public partial class Shipping : DbContext
    {
        public Shipping()
            : base("name=Shipping")
        {
        }

        public virtual DbSet<SHIPPING_COMPANY> SHIPPING_COMPANY { get; set; }

        public virtual DbSet<CARGO_SHIPPING_CAMPANY> CARGO_SHIPPING_CAMPANY { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.HasDefaultSchema("SHIPPING_COMPANY");
            modelBuilder.Entity<SHIPPING_COMPANY>()
                .Property(e => e.COMPANY_NUMBER)
                .HasPrecision(38, 0);

            modelBuilder.Entity<SHIPPING_COMPANY>()
                .Property(e => e.COMPANY_NAME)
                .IsUnicode(false);

            modelBuilder.Entity<SHIPPING_COMPANY>()
                .Property(e => e.HEADQUARTERS)
                .IsUnicode(false);
        }
    }
}
