namespace SQLServerCodeFirst_EF6_DOTNET
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class FLIGHT_DETAILS
    {
        [StringLength(50)]
        public string FLIGHT_NAME { get; set; }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int FLIGHT_NUMBER { get; set; }

        [StringLength(50)]
        public string SOURCE { get; set; }

        [StringLength(50)]
        public string DESTINATION { get; set; }
    }
}
