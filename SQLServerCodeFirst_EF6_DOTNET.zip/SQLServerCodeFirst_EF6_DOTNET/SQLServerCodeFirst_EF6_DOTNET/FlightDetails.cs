using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;

namespace SQLServerCodeFirst_EF6_DOTNET
{
    public partial class FlightDetails : DbContext
    {
        public FlightDetails()
            : base("name=FlightDetails")
        {
        }

        public virtual DbSet<FLIGHT_DETAILS> FLIGHT_DETAILS { get; set; }
        public virtual DbSet<PASSENGER_DETAILS> PASSENGER_DETAILS { get; set; }
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<FLIGHT_DETAILS>()
                .Property(e => e.FLIGHT_NAME)
                .IsFixedLength();
        }
    }
}
