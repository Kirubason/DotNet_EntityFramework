﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SQLServerCodeFirst_EF6_DOTNET
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            InsertPassengerDetails();
            UpdatePassengerDetails();
            DeletePassengertDetails();
            GetAllPassengerDetails();
        }

        public void InsertPassengerDetails()
        {
            var PassengerInfo = new PASSENGER_DETAILS
            {
                PASSENGER_NAME = "MICAH TECH",
                PASSENGER_NUMBER = 2001,
                ADDRESS = "CHENNAI",
                CONTACT = "9360586730"
            };
            using (var Context = new FlightDetails())
            {
                Context.PASSENGER_DETAILS.Add(PassengerInfo);
                Context.SaveChanges();
            }
        }
        public void UpdatePassengerDetails()
        {
            using (var Context = new FlightDetails())
            {
                PASSENGER_DETAILS ExsitingPassenger = Context.PASSENGER_DETAILS.Where(a => a.PASSENGER_NUMBER == 2001).FirstOrDefault();
                ExsitingPassenger.ADDRESS = "TIRUNELVELI";
                Context.SaveChanges();
            }
        }

        public void DeletePassengertDetails()
        {
            using (var Context = new FlightDetails())
            {
                PASSENGER_DETAILS ExsitingPassenger = Context.PASSENGER_DETAILS.Where(a => a.PASSENGER_NUMBER == 2001).FirstOrDefault();
                Context.PASSENGER_DETAILS.Remove(ExsitingPassenger);
                Context.SaveChanges();
            }
        }
        public void GetAllPassengerDetails()
        {
            List<PASSENGER_DETAILS> AllPassenger = new List<PASSENGER_DETAILS>();
            using (var Context = new FlightDetails())
            {
                AllPassenger = Context.PASSENGER_DETAILS.OrderBy(a => a.PASSENGER_NUMBER).ToList();
            }
        }
    }
}
