﻿namespace SQLServerCodeFirst_EF6_DOTNET.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class createPassengerDetailsTable : DbMigration
    {
        public override void Up()
        {
            
            CreateTable(
                "dbo.PASSENGER_DETAILS",
                c => new
                    {
                        PASSENGER_NUMBER = c.Int(nullable: false),
                        PASSENGER_NAME = c.String(maxLength: 50),
                        ADDRESS = c.String(maxLength: 50),
                        CONTACT = c.String(maxLength: 50),
                    })
                .PrimaryKey(t => t.PASSENGER_NUMBER);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.PASSENGER_DETAILS");
            DropTable("dbo.FLIGHT_DETAILS");
        }
    }
}
