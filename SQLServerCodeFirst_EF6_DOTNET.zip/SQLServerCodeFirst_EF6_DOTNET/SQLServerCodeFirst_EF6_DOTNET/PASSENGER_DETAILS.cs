﻿namespace SQLServerCodeFirst_EF6_DOTNET
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class PASSENGER_DETAILS
    {
        [StringLength(50)]
        public string PASSENGER_NAME { get; set; }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int PASSENGER_NUMBER { get; set; }

        [StringLength(50)]
        public string ADDRESS { get; set; }

        [StringLength(50)]
        public string CONTACT { get; set; }
    }
}
