﻿Below comments will be used for the Entity Framework code first migration

enable-migrations
add-migration createPassengerTable
update-database