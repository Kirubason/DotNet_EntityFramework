﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SQLServerDatabaseFirst_EF6_DOTNET
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            InsertFlightDetails();
            UpdateFlightDetails();
            DeleteFlightDetails();
            GetAllFlightDetails();
        }

        public void InsertFlightDetails()
        {
            var FlightInfo = new FLIGHT_DETAILS
            {
                FLIGHT_NAME = "BOEING",
                FLIGHT_NUMBER = 2002,
                SOURCE = "CHENNAI",
                DESTINATION = "MUMBAI"
            };
            using (var Context = new AEROSPACEEntities())
            {
                Context.FLIGHT_DETAILS.Add(FlightInfo);
                Context.SaveChanges();
            }
        }
        public void UpdateFlightDetails()
        {
            using (var Context = new AEROSPACEEntities())
            {
                FLIGHT_DETAILS ExsitingFlight = Context.FLIGHT_DETAILS.Where(a => a.FLIGHT_NUMBER == 2001).FirstOrDefault();
                ExsitingFlight.SOURCE = "AUSTRALIA";
                ExsitingFlight.DESTINATION = "NEW ZEALAND";
                Context.SaveChanges();
            }
        }

        public void DeleteFlightDetails()
        {
            using (var Context = new AEROSPACEEntities())
            {
                FLIGHT_DETAILS ExsitingFlight = Context.FLIGHT_DETAILS.Where(a => a.FLIGHT_NUMBER == 2001).FirstOrDefault();
                Context.FLIGHT_DETAILS.Remove(ExsitingFlight);
                Context.SaveChanges();
            }
        }
        public void GetAllFlightDetails()
        {
            List<FLIGHT_DETAILS> AllFilight = new List<FLIGHT_DETAILS>();
            using (var Context = new AEROSPACEEntities())
            {
                AllFilight = Context.FLIGHT_DETAILS.OrderBy(a => a.FLIGHT_NAME).ToList();
            }
        }
    }
}
